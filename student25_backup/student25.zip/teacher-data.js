const classInfo = [
    {
        "grade": 0,
        "class": 0,
        "homeroom": "이름",
        "homeroomPhone": "핸드폰",
        "sub": "기타1",
        "subPhone": "기타2"
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "이경원",
        "homeroomPhone": "010-2868-4772",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "강진복",
        "homeroomPhone": "010-4153-2818",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "이강정",
        "homeroomPhone": "010-5571-6290",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "이상수",
        "homeroomPhone": "010-2323-1393",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 3,
        "class": 1,
        "homeroom": "이관태",
        "homeroomPhone": "010-7253-4752 ",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "이갑종",
        "homeroomPhone": "010-3736-7153",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 1,
        "class": 1,
        "homeroom": "최희락",
        "homeroomPhone": "010-4087-1223",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "김덕원",
        "homeroomPhone": "010-4874-8654",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "신승현",
        "homeroomPhone": "010-9094-6599",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "최지은",
        "homeroomPhone": "010-2769-0306",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "박창우",
        "homeroomPhone": "010-9746-0083",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "이경미",
        "homeroomPhone": "010-8312-3256",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "김웅환",
        "homeroomPhone": "010-2569-7404",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "구동후",
        "homeroomPhone": "010-4747-5863",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "한현숙",
        "homeroomPhone": "010-9918-0408",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 1,
        "class": 2,
        "homeroom": "최현정",
        "homeroomPhone": "010-2435-9360",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "박성환",
        "homeroomPhone": "010-2929-2882",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "하미경",
        "homeroomPhone": "010-4551-8110",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "황철현",
        "homeroomPhone": "010-8784-0858",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 3,
        "class": 2,
        "homeroom": "손주희",
        "homeroomPhone": "010-9978-5181",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 3,
        "class": 4,
        "homeroom": "이효상",
        "homeroomPhone": "010-4161-0148",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 3,
        "class": 6,
        "homeroom": "홍지아",
        "homeroomPhone": "010-2086-2582",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "정필구",
        "homeroomPhone": "010-9248-9293 ",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 3,
        "class": 5,
        "homeroom": "김민경",
        "homeroomPhone": "010-3513-9478",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 2,
        "class": 1,
        "homeroom": "황태겸",
        "homeroomPhone": "010-8740-7288",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 2,
        "class": 5,
        "homeroom": "양지원",
        "homeroomPhone": "010-2578-5055 ",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "김선옥",
        "homeroomPhone": "010-5159-1369",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 1,
        "class": 3,
        "homeroom": "전지훈",
        "homeroomPhone": "010-4515-1898",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 2,
        "class": 4,
        "homeroom": "백승민",
        "homeroomPhone": "010-6371-1357",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 2,
        "class": 3,
        "homeroom": "이민희",
        "homeroomPhone": "010-9152-8979",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 2,
        "class": 6,
        "homeroom": "권대호",
        "homeroomPhone": "010-5023-9707",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 2,
        "class": 2,
        "homeroom": "정민주",
        "homeroomPhone": "010-2070-1008 ",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 1,
        "class": 4,
        "homeroom": "이혜영",
        "homeroomPhone": "010-2663-4151",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "김태경",
        "homeroomPhone": "010-7619-3231 ",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 1,
        "class": 5,
        "homeroom": "정혜인",
        "homeroomPhone": "010-8904-1061",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 3,
        "class": 3,
        "homeroom": "손수곤",
        "homeroomPhone": "010-9666-5982",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 1,
        "class": 6,
        "homeroom": "정유리",
        "homeroomPhone": "010-5759-0564",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "김현희",
        "homeroomPhone": "010-3534-2061",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "김동길",
        "homeroomPhone": "010-2954-1785 ",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "권재환",
        "homeroomPhone": "010-8508-5432",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "엄기환",
        "homeroomPhone": "010-3466-5728",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "공상옥",
        "homeroomPhone": "010-9505-5356",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "구태윤",
        "homeroomPhone": "010-2088-284",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "우재준",
        "homeroomPhone": "010-4026-6555",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "오 승",
        "homeroomPhone": "010-7159-9190",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "여다윤",
        "homeroomPhone": "",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "김나경",
        "homeroomPhone": "010-5755-3647 ",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "박경희",
        "homeroomPhone": "010-4569-4280 ",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "강준규",
        "homeroomPhone": "010-7913-9024",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "변재학",
        "homeroomPhone": "010-6861-7667 ",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "강정자",
        "homeroomPhone": "010-4270-4515",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "이성숙",
        "homeroomPhone": "010-4156-3847",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "김원철",
        "homeroomPhone": "010-4540-9112 ",
        "sub": "",
        "subPhone": ""
    },
    {
        "grade": 0,
        "class": 0,
        "homeroom": "송관웅",
        "homeroomPhone": "010-2770-2177",
        "sub": "",
        "subPhone": ""
    }
];